import { Layout, Breadcrumb, theme } from "antd";

const { Header } = Layout;

export const AppHeader = () => {
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const now = new Date();

  // Текущая дата
  const date = now.toLocaleDateString(undefined, {
    weekday: "short",
    day: "numeric",
    month: "short",
  });

  // текущие время
  const time = now.toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <Header
      style={{
        background: colorBgContainer,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <Breadcrumb items={[{ title: "Главная" }, { title: "Все задачи" }]} />

      <div style={{ textAlign: "right", lineHeight: 1.2 }}>
        <div style={{ fontSize: 12, opacity: 0.7 }}>{date}</div>
        <div style={{ fontSize: 20, fontWeight: 600 }}>{time}</div>
      </div>
    </Header>
  );
};
